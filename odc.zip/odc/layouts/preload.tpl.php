<?php  if(!defined('BASEPATH')) exit('No direct script access allowed'); ?> 		
		<div id="preloader">
          <div class="preloader-position"> 
            <img src="<?php echo THEMES_PATH.$this->theme_folder.'/'.$this->theme.'/'; ?>assets/img/logo-colored.png" alt="logo" >
            <div class="progress">
              <div class="indeterminate"></div>
            </div>
          </div>
        </div>
        <!-- <div id="preloader" class="preloader-wrapper big active">
	      <div class="spinner-layer spinner-blue">
	        <div class="circle-clipper left">
	          <div class="circle"></div>
	        </div><div class="gap-patch">
	          <div class="circle"></div>
	        </div><div class="circle-clipper right">
	          <div class="circle"></div>
	        </div>
	      </div>

	    </div> -->
        